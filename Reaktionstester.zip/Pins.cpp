#include "Arduino.h"
#include "Pins.h"

int timeDelayStart = 200;                                                       
int reaktiontestZeit;                                                           
int start;                                                                      
int Dauer;                                                                      
int AnzeigeDelay = 2000;        

Pins::Pins(int _ledPin1, int _ledPin2, int _ledPin3, int _ledPin4, int _ledPin5, int _ledPin6, int _ledPin7, int _buttonPin){
ledPin1 = _ledPin1;
ledPin2 = _ledPin2;
ledPin3 = _ledPin3;
ledPin4 = _ledPin4;
ledPin5 = _ledPin5;
ledPin6 = _ledPin6;
ledPin7 = _ledPin7;
buttonPin = _buttonPin; 

pinMode(ledPin1,OUTPUT);                                                    
pinMode(ledPin2,OUTPUT);
pinMode(ledPin3,OUTPUT);
pinMode(ledPin4,OUTPUT);
pinMode(ledPin5,OUTPUT);
pinMode(ledPin6,OUTPUT);
pinMode(ledPin7,OUTPUT);
pinMode(buttonPin,INPUT); 

}

void Pins::startAnimation() {                                                         
  for (int i = 2; i <= 8; i++) {                                       
    digitalWrite(i, HIGH);
    delay(timeDelayStart);
    digitalWrite(i, LOW);
  }
}


void Pins::reaktion()  {                                                             
  while (digitalRead(buttonPin) == HIGH) {                                     
    1;
  }
  
for (int i = ledPin1; i <= ledPin7; i++) {                                     
  digitalWrite(i, HIGH);
  }

reaktiontestZeit = random(500, 10000);                                       
delay(reaktiontestZeit);

for (int i = ledPin1; i <= ledPin7; i++) {                                    
  digitalWrite(i, LOW);
  }

     start = millis();                                                        
     while(digitalRead(buttonPin) == LOW)                                     
     {
       1;                                                                     
     }
     Dauer = millis() - start;                                                
   
}

void Pins::zeitAnzeige()                                                          
{
  if (Dauer<= 100)
  {
    digitalWrite(ledPin1, HIGH);
    delay(AnzeigeDelay);
  }
  else if (Dauer<= 200)
  {
    for (int i = ledPin1; i <= ledPin2; i++) { 
    digitalWrite(i, HIGH);
    }
    delay(AnzeigeDelay);
  }
  else if (Dauer<= 300)
  {
    for (int i = ledPin1; i <= ledPin3; i++) { 
    digitalWrite(i, HIGH);
    }
    delay(AnzeigeDelay);
  }
  else if (Dauer<= 400)
  {
    for (int i = ledPin1; i <= ledPin4; i++) { 
    digitalWrite(i, HIGH);
    }
    delay(AnzeigeDelay);
  }
  else if (Dauer<= 500)
  {
    for (int i = ledPin1; i <= ledPin5; i++) { 
    digitalWrite(i, HIGH);
    }
    delay(AnzeigeDelay);
  }
   else if (Dauer<= 600)
  {
    for (int i = ledPin1; i <= ledPin6; i++) { 
    digitalWrite(i, HIGH);
    }
    delay(AnzeigeDelay);
  }
   else if (Dauer> 600)
  {
    for (int i = ledPin1; i <= ledPin7; i++) { 
    digitalWrite(i, HIGH);
    }
    delay(AnzeigeDelay);
  }  
}
