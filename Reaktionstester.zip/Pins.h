#ifndef Pins_h
#define Pins_h
class Pins {
  public:

    Pins(int _ledPin1, int _ledPin2, int _ledPin3, int _ledPin4, int _ledPin5, int _ledPin6, int _ledPin7, int _buttonPin);
  
   
   void startAnimation();                                                          
   void reaktion();
   void zeitAnzeige();


int ledPin1;
int ledPin2;	
int ledPin3;	
int ledPin4;	
int ledPin5;	
int ledPin6;
int ledPin7;
int buttonPin;
	


};
#endif